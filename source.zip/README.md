# Serverless telegram bot
Hosting telegram bot with Yandex.Cloud Functions

Full setup guide: [Прыжок до небес: запускаем телеграм бота на Python в serverless облаке](https://habr.com/ru/post/550456/)
